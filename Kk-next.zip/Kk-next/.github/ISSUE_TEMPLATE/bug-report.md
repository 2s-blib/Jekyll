---
name: Bug report
about: Create a report to help us improve
title: ''
labels: ''
assignees: ''

---

**Version information (版本信息)**
- ChatUI or ChatUI Pro?
- ChatUI Version:
- React Version:
- OS Version:
- Browser Version:

**Describe the bug (描述问题)**

**Steps To Reproduce (重现步骤)**
1. 
2. 

**Link to minimal reproduction (最小化重现链接)**

**Expected behavior (期望的结果是什么)**
