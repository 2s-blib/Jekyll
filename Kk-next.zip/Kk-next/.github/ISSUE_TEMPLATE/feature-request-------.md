---
name: Feature request (功能要求)
about: Suggest an idea for this project
title: ''
labels: enhancement
assignees: ''

---

**What problem does this feature solve? (这个功能解决了什么问题)**

**Describe the solution you'd like (描述您想要的解决方案)**

**What does the proposed API look like?  (你期望的 API 是怎样的)**
