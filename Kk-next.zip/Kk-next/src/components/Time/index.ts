export { Time } from './Time';
export type { TimeProps } from './Time';
